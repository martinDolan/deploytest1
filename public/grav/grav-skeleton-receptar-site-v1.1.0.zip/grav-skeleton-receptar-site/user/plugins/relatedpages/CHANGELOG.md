# v1.1.1
## 01/15/2016

1. [](#improved)
    * Disabled content-to-content matching by default (performance hit)
    * Small refactor

# v1.1.0
## 09/11/2015

1. [](#improved)
    * Added blueprints for admin compatibility
   
# v1.0.3
## 12/04/2015

1. [](#new)
    * ChangeLog started...
